package com.niit.jewelcart.dao;

public interface UserDAO 
{
	public void addUser();
}
