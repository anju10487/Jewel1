package com.niit.jewelcart.dao;

public class CategoryDAOImpl 
{
	

}
