package com.niit.jewelcart.dao;

public interface CategoryDAO {

}
