package com.niit.jewelcart;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public static void main(String[] args)
{
	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
	
}